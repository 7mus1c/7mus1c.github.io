# `Font` 字体

**当前项目仅供学习记录，不作任何商业用途！**

- `FiraCode`

- `Operator Mono`

- `Operator Mono Lig`

- `Operator Mono SSm`

## `FiraCode`

**[FiraCode](https://github.com/beichensky/Font/tree/master/FiraCode)**

等宽字体

## `Operator Mono`

**[Operator Mono](https://github.com/beichensky/Font/tree/master/Operator%20Mono)**

可以使用连体字，安装 `Operator Mono` 字体 之前需要先安装 `FiraCode` 字体

## `Operator Mono Lig`

**[Operator Mono Lig](https://github.com/kiliman/operator-mono-lig)**

## `Operator Mono SSm`

**`Operator Mono SSm`**

## 资源下载

```bash
git clone https://github.com/beichensky/Font.git

https://github.com/beichensky/Font
```

## 字体安装及在 `VSCode` 中配置

1. 先安装 FiraCode
2. 再安装 Operator Mono
   1. Mac 上如何安装字体的图文: 按住cmd + space，搜索“字体册”
   2. 点击 + 在弹窗中选中字体所在的文件夹，然后确定即可
3. 在 `VSCode` 中配置字体

   ```json
   {
     "editor.fontFamily": "Operator Mono",
     "editor.fontLigatures": true, // 这个控制是否启用字体连字，true启用，false不启用，这里选择启用
     "editor.tokenColorCustomizations": {
       "textMateRules": [
         {
           "name": "italic font",
           "scope": [
             "comment",
             "keyword",
             "storage",
             "keyword.control.import",
             "keyword.control.default",
             "keyword.control.from",
             "keyword.operator.new",
             "keyword.control.export",
             "keyword.control.flow",
             "storage.type.class",
             "storage.type.function",
             "storage.type",
             "storage.type.class",
             "variable.language",
             "variable.language.super",
             "variable.language.this",
             "meta.class",
             "meta.var.expr",
             "constant.language.null",
             "support.type.primitive",
             "entity.name.method.js",
             "entity.other.attribute-name",
             "punctuation.definition.comment",
             "text.html.basic entity.other.attribute-name.html",
             "text.html.basic entity.other.attribute-name",
             "tag.decorator.js entity.name.tag.js",
             "tag.decorator.js punctuation.definition.tag.js",
             "source.js constant.other.object.key.js string.unquoted.label.js"
           ],
           "settings": {
             "fontStyle": "italic"
           }
         }
       ]
     }
   }
   ```
